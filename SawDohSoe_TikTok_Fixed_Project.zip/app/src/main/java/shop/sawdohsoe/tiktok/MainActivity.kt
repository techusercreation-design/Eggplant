package shop.sawdohsoe.tiktok

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import okhttp3.Cache
import okhttp3.CacheControl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayInputStream
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var offlineLayout: LinearLayout
    private lateinit var offlineBanner: TextView
    private lateinit var btnRetry: Button

    private val targetUrl = "https://www.tiktok.com/@sawdohsoepoezan"
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private lateinit var okHttpClient: OkHttpClient
    private lateinit var htmlCacheDir: File

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val data: Intent? = result.data
            val results: Array<Uri>? = when {
                data?.clipData != null -> {
                    val count = data.clipData!!.itemCount
                    Array(count) { i -> data.clipData!!.getItemAt(i).uri }
                }
                data?.data != null -> arrayOf(data.data!!)
                else -> null
            }
            filePathCallback?.onReceiveValue(results)
        } else {
            filePathCallback?.onReceiveValue(null)
        }
        filePathCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout)
        progressBar = findViewById(R.id.progressBar)
        offlineLayout = findViewById(R.id.offlineLayout)
        offlineBanner = findViewById(R.id.offlineBanner)
        btnRetry = findViewById(R.id.btnRetry)

        setupLocalDiskCache()
        setupWebView()
        setupPullToRefresh()
        setupRetryButton()
        setupBackNavigation()

        loadWebsite()
    }

    private fun setupLocalDiskCache() {
        htmlCacheDir = File(cacheDir, "sawdohsoe_tiktok_cache")
        if (!htmlCacheDir.exists()) {
            htmlCacheDir.mkdirs()
        }

        val httpCacheDir = File(cacheDir, "sawdohsoe_tiktok_http")
        val cacheSize = 100L * 1024L * 1024L

        okHttpClient = OkHttpClient.Builder()
            .cache(Cache(httpCacheDir, cacheSize))
            .addNetworkInterceptor { chain ->
                val response = chain.proceed(chain.request())
                response.newBuilder()
                    .removeHeader("Pragma")
                    .removeHeader("Cache-Control")
                    .header("Cache-Control", "public, max-age=" + (60 * 60 * 24 * 30))
                    .build()
            }
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    private fun urlToKey(url: String): String {
        val cleanUrl = url.split("#")[0].trimEnd('/')
        val bytes = MessageDigest.getInstance("MD5").digest(cleanUrl.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webSettings: WebSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.databaseEnabled = true
        webSettings.loadsImagesAutomatically = true
        webSettings.allowFileAccess = true
        webSettings.allowContentAccess = true
        webSettings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        updateCacheMode()

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                if (request == null || request.method != "GET") {
                    return super.shouldInterceptRequest(view, request)
                }

                val url = request.url.toString()
                if (!url.startsWith("http")) {
                    return super.shouldInterceptRequest(view, request)
                }

                val isHtmlPage = request.isForMainFrame || (request.requestHeaders["Accept"]?.contains("text/html") == true)
                val pageCacheFile = File(htmlCacheDir, urlToKey(url) + ".html")

                if (!isNetworkAvailable() && isHtmlPage && pageCacheFile.exists()) {
                    return try {
                        WebResourceResponse(
                            "text/html",
                            "UTF-8",
                            ByteArrayInputStream(pageCacheFile.readBytes())
                        )
                    } catch (e: Exception) {
                        super.shouldInterceptRequest(view, request)
                    }
                }

                return try {
                    val reqBuilder = Request.Builder().url(url)
                    request.requestHeaders.forEach { (k, v) ->
                        if (!k.equals("Accept-Encoding", ignoreCase = true)) {
                            reqBuilder.addHeader(k, v)
                        }
                    }

                    val cookie = CookieManager.getInstance().getCookie(url)
                    if (!cookie.isNullOrEmpty()) {
                        reqBuilder.addHeader("Cookie", cookie)
                    }

                    if (!isNetworkAvailable()) {
                        reqBuilder.cacheControl(CacheControl.FORCE_CACHE)
                    }

                    val response = okHttpClient.newCall(reqBuilder.build()).execute()
                    if (response.isSuccessful && response.body != null) {
                        val contentType = response.header("Content-Type", "text/html") ?: "text/html"
                        val mimeType = contentType.split(";")[0].trim()
                        val charset = if (contentType.contains("charset=", ignoreCase = true)) {
                            contentType.substringAfter("charset=").split(";")[0].trim()
                        } else {
                            "UTF-8"
                        }

                        if (isHtmlPage) {
                            val bytes = response.body!!.bytes()
                            if (bytes.isNotEmpty()) {
                                pageCacheFile.writeBytes(bytes)
                            }
                            WebResourceResponse(mimeType, charset, ByteArrayInputStream(bytes))
                        } else {
                            WebResourceResponse(mimeType, charset, response.body!!.byteStream())
                        }
                    } else if (isHtmlPage && pageCacheFile.exists()) {
                        WebResourceResponse(
                            "text/html",
                            "UTF-8",
                            ByteArrayInputStream(pageCacheFile.readBytes())
                        )
                    } else {
                        super.shouldInterceptRequest(view, request)
                    }
                } catch (e: Exception) {
                    if (isHtmlPage && pageCacheFile.exists()) {
                        WebResourceResponse(
                            "text/html",
                            "UTF-8",
                            ByteArrayInputStream(pageCacheFile.readBytes())
                        )
                    } else {
                        super.shouldInterceptRequest(view, request)
                    }
                }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                updateCacheMode()
                progressBar.visibility = View.VISIBLE
                offlineLayout.visibility = View.GONE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                swipeRefreshLayout.isRefreshing = false
                updateCacheMode()
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    val url = request.url.toString()
                    val pageCacheFile = File(htmlCacheDir, urlToKey(url) + ".html")
                    if (!pageCacheFile.exists()) {
                        progressBar.visibility = View.GONE
                        swipeRefreshLayout.isRefreshing = false
                        showOfflineView()
                    }
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url.toString()
                if (url.startsWith("tel:") || url.startsWith("viber:") ||
                    url.startsWith("fb-messenger:") || url.startsWith("https://m.me/") ||
                    url.startsWith("mailto:") || url.startsWith("intent:") ||
                    url.contains("tiktok.com/share") || url.contains("play.google.com")) {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        startActivity(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    return true
                }
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback

                return try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "image/*"
                    }
                    fileChooserLauncher.launch(intent)
                    true
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback = null
                    false
                }
            }
        }
    }

    private fun updateCacheMode() {
        val online = isNetworkAvailable()
        runOnUiThread {
            if (online) {
                webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
                offlineBanner.visibility = View.GONE
            } else {
                webView.settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
                offlineBanner.visibility = View.VISIBLE
            }
        }
    }

    private fun setupPullToRefresh() {
        swipeRefreshLayout.setColorSchemeResources(R.color.eggplant_primary)
        swipeRefreshLayout.setOnRefreshListener {
            updateCacheMode()
            if (isNetworkAvailable()) {
                offlineLayout.visibility = View.GONE
                webView.reload()
            } else {
                swipeRefreshLayout.isRefreshing = false
                Toast.makeText(
                    this,
                    "အင်တာနက်မရှိပါ - ယခင်သိမ်းဆည်းထားသော TikTok ဒေတာများကို ပြသနေပါသည်",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        webView.setOnScrollChangeListener { _, _, scrollY, _, _ ->
            swipeRefreshLayout.isEnabled = (scrollY == 0)
        }
    }

    private fun setupRetryButton() {
        btnRetry.setOnClickListener {
            loadWebsite()
        }
    }

    private fun loadWebsite() {
        updateCacheMode()
        offlineLayout.visibility = View.GONE

        if (webView.url == null) {
            webView.loadUrl(targetUrl)
        } else {
            webView.reload()
        }
    }

    private fun showOfflineView() {
        offlineLayout.visibility = View.VISIBLE
    }

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork ?: return false
        val activeNetwork = connectivityManager.getNetworkCapabilities(network) ?: return false
        return when {
            activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
            activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
            activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
            else -> false
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (offlineLayout.visibility == View.VISIBLE) {
                    if (webView.canGoBack()) {
                        offlineLayout.visibility = View.GONE
                        webView.goBack()
                    } else {
                        finish()
                    }
                } else if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })
    }
}
