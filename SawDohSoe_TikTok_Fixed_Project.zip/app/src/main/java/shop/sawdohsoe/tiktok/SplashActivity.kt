package shop.sawdohsoe.tiktok

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val eggplantView = findViewById<TextView>(R.id.animatedEggplant)
        val bounceAnim = AnimationUtils.loadAnimation(this, R.anim.eggplant_bounce)
        eggplantView.startAnimation(bounceAnim)

        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }, 2500)
    }
}
